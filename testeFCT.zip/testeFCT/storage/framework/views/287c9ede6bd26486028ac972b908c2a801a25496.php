<?php $__env->startSection('title', 'Página principal - admin'); ?>
<?php $__env->startSection('content'); ?>

    <div id="wrapper" >
        <div id="page" class="container">
            <!-- Message -->
            <?php if(Session::has('message')): ?>
                <p ><?php echo e(Session::get('message')); ?></p>
        <?php endif; ?>

        <!-- Form -->
            <form method='post' action='/uploadFile' enctype='multipart/form-data' >
                <?php echo e(csrf_field()); ?>

                <input type='file' name='file' >
                <input type='submit' name='submit' value='Import'>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hugonunes/WWW/testeFCT/resources/views/pagAdmin.blade.php ENDPATH**/ ?>