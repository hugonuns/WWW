<?php
 ?><?php /**PATH C:\Users\joaop\testeFCT\resources\views/test.blade.php ENDPATH**/ ?>
