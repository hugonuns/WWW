
    <!-- Message -->
    <?php if(Session::has('message')): ?>
        <p ><?php echo e(Session::get('message')); ?></p>
    <?php endif; ?>

    <!-- Form -->
    <form method='post' action='/uploadFile' enctype='multipart/form-data' >
        <?php echo e(csrf_field()); ?>

        <input type='file' name='file' >
        <input type='submit' name='submit' value='Import'>
    </form>
<?php /**PATH C:\Users\joaop\testeFCT\resources\views/pagAdmin.blade.php ENDPATH**/ ?>