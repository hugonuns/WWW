<?php $__env->startSection('title', 'Página principal - admin'); ?>
<?php $__env->startSection('content'); ?>

    <div id="wrapper" >
        <div id="page" class="container">
            <!-- Message -->
            <?php if(Session::has('message')): ?>
                <p ><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>

            <!-- Form -->
            <form method='post' action='/uploadFile?para=<?php echo e($entidadeAction); ?>' enctype='multipart/form-data' >
                <?php echo e(csrf_field()); ?>

                <p>Import tabela <?php echo e($entidadeStr); ?></p>
                <input type='file' name='file' >
                <input type='submit' name='submit' value='Import'>
            </form>
        </div>

        <?php if(count($importData_arr)): ?>
            <pre>
            <?php $__currentLoopData = $importData_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container">
                    <p><?php echo e($data['existe']?'ja existe':'inserido'); ?></p>
                    <?php
                        echo ($data['elem'])->toHtml();
                    ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </pre>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hugonunes/WWW/testeFCT/resources/views/UploadFile.blade.php ENDPATH**/ ?>