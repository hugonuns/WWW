<?php $__env->startSection('title', 'Página principal - professor'); ?>
<?php $__env->startSection('content'); ?>

    <div id="wrapper" >
        <div id="page" class="container">
            <div class="dropdown">
                <button class="button">ano letivo</button>
                <!-- TODO foreach para precorrer a bd pelos anos letivos existentes-->
                <div class="dropdown-content">
                    <a href="#">X</a>
                    <a href="#">Y</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="button">registar visita</button>
            </div>
            <div class="dropdown">
                <button class="button">registar aluno</button><!-- TODO para ultimo-->
            </div>
        </div>

        <!--<7?= alunoController::getListaAluno(true); ?>-->
        <div id="page" class="container">
        <table class="table table-bordered table-striped table-sm">
            <thead>
            <tr>
                <th>#</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Telemovel</th>
                <th>
                    <a href="<?php echo e(route('alunos.create')); ?>" class="btn btn-info btn-sm" >Novo</a>
                </th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($aluno->id); ?></td>
                    <td><?php echo e($aluno->nome); ?></td>
                    <td><?php echo e($aluno->email); ?></td>
                    <td><?php echo e($aluno->telemovel); ?></td>
                    <td>
                        <a href="" class="btn btn-warning btn-sm">Editar</a>
                        <form method="POST" action="" style="display: inline" onsubmit="return confirm('Deseja excluir este registro?');" >
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="delete" >
                            <button class="btn btn-danger btn-sm">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">Nenhum registro encontrado para listar</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\joaop\testeFCT\resources\views/pagProf.blade.php ENDPATH**/ ?>