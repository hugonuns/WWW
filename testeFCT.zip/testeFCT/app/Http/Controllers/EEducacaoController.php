<?php

namespace App\Http\Controllers;

use App\Models\EEducacao;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class EEducacaoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EEducacao  $eEducacao
     * @return \Illuminate\Http\Response
     */
    public function show(EEducacao $eEducacao)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EEducacao  $eEducacao
     * @return \Illuminate\Http\Response
     */
    public function edit(EEducacao $eEducacao)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EEducacao  $eEducacao
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EEducacao $eEducacao)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EEducacao  $eEducacao
     * @return \Illuminate\Http\Response
     */
    public function destroy(EEducacao $eEducacao)
    {
        //
    }

}
