<?php

namespace App\Http\Controllers;

use App\Models\DiretorCurso;
use Illuminate\Http\Request;

class DiretorCursoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DiretorCurso  $diretorCurso
     * @return \Illuminate\Http\Response
     */
    public function show(DiretorCurso $diretorCurso)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DiretorCurso  $diretorCurso
     * @return \Illuminate\Http\Response
     */
    public function edit(DiretorCurso $diretorCurso)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DiretorCurso  $diretorCurso
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DiretorCurso $diretorCurso)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DiretorCurso  $diretorCurso
     * @return \Illuminate\Http\Response
     */
    public function destroy(DiretorCurso $diretorCurso)
    {
        //
    }
}
